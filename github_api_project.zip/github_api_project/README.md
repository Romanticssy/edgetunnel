# GitHub API 对接模板

这是一个 Cloudflare Pages 项目模板，包含 API 对接功能。

## 功能
- `/api` 路由会转发请求到 `https://ip.8888888888.eu.org/api`
- 前端页面可以调用 `/api` 并显示返回结果

## 部署
1. 上传到 GitHub 仓库。
2. 在 Cloudflare Pages 创建项目，绑定该仓库。
3. Cloudflare Pages 会自动识别 `functions/` 文件夹并启用 Functions。
4. 部署完成后访问：
   - 首页: `https://你的域名/`
   - API: `https://你的域名/api`
